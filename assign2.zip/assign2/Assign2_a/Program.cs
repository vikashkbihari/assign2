﻿using System;

namespace HelloWorld
{   class Array
     {   
         int _size;
         public Array(int size){
             this._size=size;
             int [] arr= new int[this._size];
            
             for(int i=0;i<this._size; i++){
                 arr[i]=i+1;
                 if(arr[i]>10){
                     Console.WriteLine("Array crosses 10 !");
                     break;
                 }
             }
         }
     }
    class Program
    { 
        public static void Main()
            {    int size1;
                Console.WriteLine("Enter the size of Array");
               size1=int.Parse(Console.ReadLine());
                Array A1= new Array(size1);

            }

    }
}
